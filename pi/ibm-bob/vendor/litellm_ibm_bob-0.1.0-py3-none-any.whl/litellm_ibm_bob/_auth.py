"""API-key classification and backend/auth-header derivation.

Mirrors the logic in bob-unpacked.js:
* ``nU(apiKey)``   → legacy ``sk-``/``pk-`` key, must use the old backend.
* ``isApiKey``     → key does not parse as JWT, use ``Apikey`` auth scheme.
* Otherwise        → JWT, use ``Bearer`` auth scheme.
"""

from __future__ import annotations

import base64
import binascii
import enum
import json

from ._constants import (
    CHAT_PATH_AUTHN,
    CHAT_PATH_LEGACY,
    DEFAULT_BACKEND_URL,
    DEFAULT_OLD_BACKEND_URL,
    MODELS_PATH_AUTHN,
    MODELS_PATH_LEGACY,
)


class KeyKind(enum.StrEnum):
    LEGACY = "legacy"  # sk-/pk- prefixed: old backend, Bearer
    JWT = "jwt"  # parses as JWT: new backend, Bearer
    OPAQUE = "opaque"  # everything else (e.g. bob_prod_...): new backend, Apikey


def classify_key(api_key: str) -> KeyKind:
    """Inspect ``api_key`` and return its handling category."""

    if not api_key:
        raise ValueError("api_key is empty")
    if api_key.startswith(("sk-", "pk-")):
        return KeyKind.LEGACY
    if _is_jwt(api_key):
        return KeyKind.JWT
    return KeyKind.OPAQUE


def _is_jwt(token: str) -> bool:
    parts = token.split(".")
    if len(parts) < 2:
        return False
    payload = parts[1]
    padded = payload + "=" * (-len(payload) % 4)
    try:
        decoded = base64.urlsafe_b64decode(padded.encode("ascii"))
        json.loads(decoded.decode("utf-8"))
    except (binascii.Error, UnicodeDecodeError, json.JSONDecodeError, ValueError):
        return False
    return True


def base_url_for(api_key: str, *, override: str | None = None) -> str:
    """Return the host to talk to for this key.

    ``override`` (e.g. ``$CUSTOM_BASE_URL``) wins unconditionally.
    """

    if override:
        return override.rstrip("/")
    if classify_key(api_key) is KeyKind.LEGACY:
        return DEFAULT_OLD_BACKEND_URL
    return DEFAULT_BACKEND_URL


def authorization_header(api_key: str, *, kind: KeyKind | None = None) -> str:
    """Render the ``Authorization`` header value for ``api_key``."""

    if kind is None:
        kind = classify_key(api_key)
    if kind is KeyKind.OPAQUE:
        return f"Apikey {api_key}"
    return f"Bearer {api_key}"


def is_authn_backend(base_url: str, *, kind: KeyKind) -> bool:
    """Return True for the modern ``api.us-east.bob.ibm.com``-style backend.

    The JS implementation's ``isAuthnBackend()`` returns ``false`` for legacy
    keys and ``true`` for everything else (the literal expression
    ``baseUrl.includes("api.dev.bob.ibm.com") || true`` always yields true).
    """

    if kind is KeyKind.LEGACY:
        return False
    # Defensive: if the user pointed CUSTOM_BASE_URL at the *old* host we
    # still want to use the legacy paths.
    return base_url.rstrip("/") != DEFAULT_OLD_BACKEND_URL


def chat_completions_path(*, authn: bool) -> str:
    return CHAT_PATH_AUTHN if authn else CHAT_PATH_LEGACY


def models_info_path(*, authn: bool) -> str:
    return MODELS_PATH_AUTHN if authn else MODELS_PATH_LEGACY


def should_sign_url(url: str, base_url: str) -> bool:
    """Mirror ``Lu.shouldSignUrl`` — sign only when targeting the prod host."""

    if DEFAULT_BACKEND_URL in url:
        return True
    return bool(base_url and base_url in url and base_url != DEFAULT_OLD_BACKEND_URL)
