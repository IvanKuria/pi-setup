"""HMAC request signing — port of ``UFn``/``aQs`` from bob-unpacked.js.

The Node implementation derives a deterministic timestamp + signature pair:

    timestamp   = new Date().toISOString()                    // 24-char ISO-8601 millis
    body_hash   = sha256_hex(body_serialized_to_string)       // empty body → sha256 of ""
    str_to_sign = `${METHOD}\\n${path_and_search}\\n${ts}\\n${body_hash}`
    signature   = hmac_sha256_hex(str_to_sign, secret_utf8)
"""

from __future__ import annotations

import datetime as _dt
import hashlib
import hmac
from typing import TypedDict


class SignatureHeaders(TypedDict):
    x_request_timestamp: str
    x_request_signature: str


def iso_timestamp(now: _dt.datetime | None = None) -> str:
    """Return an RFC-3339 timestamp in the exact shape Node emits.

    Node's ``Date.prototype.toISOString()`` is ``YYYY-MM-DDTHH:MM:SS.mmmZ`` —
    always millisecond precision (3 digits), always ``Z`` suffix, never a
    timezone offset.
    """

    if now is None:
        now = _dt.datetime.now(tz=_dt.UTC)
    elif now.tzinfo is None:
        now = now.replace(tzinfo=_dt.UTC)
    else:
        now = now.astimezone(_dt.UTC)
    return now.strftime("%Y-%m-%dT%H:%M:%S.") + f"{now.microsecond // 1000:03d}Z"


def compute_signature(
    *,
    method: str,
    path_with_query: str,
    timestamp: str,
    body: str,
    secret: str | bytes,
) -> str:
    """Return the HMAC-SHA256 hex digest of the canonical request."""

    body_hash = hashlib.sha256(body.encode("utf-8")).hexdigest()
    str_to_sign = f"{method.upper()}\n{path_with_query}\n{timestamp}\n{body_hash}"
    key = secret.encode("utf-8") if isinstance(secret, str) else secret
    return hmac.new(key, str_to_sign.encode("utf-8"), hashlib.sha256).hexdigest()


def sign_request(
    *,
    method: str,
    path_with_query: str,
    body: str,
    secret: str | bytes,
    now: _dt.datetime | None = None,
) -> dict[str, str]:
    """One-shot helper: return the pair of headers to attach to a request."""

    ts = iso_timestamp(now)
    sig = compute_signature(
        method=method,
        path_with_query=path_with_query,
        timestamp=ts,
        body=body,
        secret=secret,
    )
    return {"x-request-timestamp": ts, "x-request-signature": sig}


def serialize_body(body: object) -> str:
    """Serialize a request body to the exact string Node feeds into the hash.

    Mirrors ``Lu.serializeBody`` — JSON-encodes dicts/lists, passes strings
    through verbatim, decodes bytes as UTF-8.
    """

    if body is None or body == "":
        return ""
    if isinstance(body, str):
        return body
    if isinstance(body, (bytes, bytearray)):
        return bytes(body).decode("utf-8")
    import json as _json

    return _json.dumps(body, separators=(",", ":"), ensure_ascii=False)
