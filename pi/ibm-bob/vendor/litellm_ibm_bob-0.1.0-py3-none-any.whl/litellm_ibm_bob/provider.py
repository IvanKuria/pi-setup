"""LiteLLM custom provider for IBM Bob.

Register by importing this module — it appends an ``ibm-bob`` entry to
``litellm.custom_provider_map``. Then call::

    litellm.completion(model="ibm-bob/<model>", messages=[...], api_key=...)
"""

from __future__ import annotations

import json
import os
from collections.abc import AsyncIterator, Iterator
from typing import Any

import httpx
from litellm import CustomLLM
from litellm.types.utils import (
    Choices,
    EmbeddingResponse,
    GenericStreamingChunk,
    Message,
    ModelResponse,
)

from . import _auth
from ._constants import EMBEDDINGS_PATH
from ._profile import resolve_identity_async, resolve_identity_sync
from ._transport import AsyncBobTransport, BobTransport, TransportConfig

PROVIDER_NAME = "ibm-bob"


def _strip_prefix(model: str) -> str:
    for prefix in (f"{PROVIDER_NAME}/", "bob/"):
        if model.startswith(prefix):
            return model[len(prefix) :]
    return model


def _resolve_config(
    *,
    api_key: str | None,
    api_base: str | None,
    optional_params: dict[str, Any] | None,
) -> TransportConfig:
    key = api_key or os.environ.get("BOBSHELL_API_KEY")
    if not key:
        raise ValueError(
            "BOBSHELL_API_KEY not set; pass `api_key=` to litellm.completion "
            "or export BOBSHELL_API_KEY"
        )
    base = api_base or os.environ.get("CUSTOM_BASE_URL")
    extras: dict[str, Any] = optional_params or {}
    # Match bob's CLI flag semantics: only --instance-id / --team-id can override
    # the auto-derived values. No env vars are consulted (bob has none either).
    return TransportConfig(
        api_key=key,
        base_url=base,
        instance_id=extras.get("instance_id"),
        team_id=extras.get("team_id"),
    )


def _build_chat_payload(
    *,
    model: str,
    messages: list[dict[str, Any]],
    optional_params: dict[str, Any],
    stream: bool,
) -> dict[str, Any]:
    payload: dict[str, Any] = {"model": _strip_prefix(model), "messages": messages}
    # Pass-through standard OpenAI sampling/tool params from optional_params.
    passthrough_keys = (
        "temperature",
        "top_p",
        "max_tokens",
        "max_completion_tokens",
        "n",
        "stop",
        "presence_penalty",
        "frequency_penalty",
        "logit_bias",
        "user",
        "tools",
        "tool_choice",
        "response_format",
        "seed",
        "parallel_tool_calls",
    )
    for key in passthrough_keys:
        if key in optional_params and optional_params[key] is not None:
            payload[key] = optional_params[key]

    user_metadata = optional_params.get("metadata") or {}
    payload["metadata"] = {
        "platformTitle": "bobshell-litellm",
        "mode": user_metadata.get("mode", "default"),
        "taskId": user_metadata.get("taskId") or user_metadata.get("task_id") or "",
        "tags": list(user_metadata.get("tags") or []),
        **{
            k: v for k, v in user_metadata.items() if k not in {"mode", "taskId", "task_id", "tags"}
        },
    }
    if stream:
        payload["stream"] = True
        payload["stream_options"] = optional_params.get("stream_options") or {"include_usage": True}
    extra_body = optional_params.get("extra_body") or {}
    payload.update(extra_body)
    return payload


def _chat_path(cfg: TransportConfig) -> str:
    kind = _auth.classify_key(cfg.api_key)
    authn = _auth.is_authn_backend(cfg.resolved_base_url(), kind=kind)
    return _auth.chat_completions_path(authn=authn)


def _apply_identity(cfg: TransportConfig, transport: BobTransport) -> None:
    if cfg.instance_id and cfg.team_id:
        return
    identity = resolve_identity_sync(
        transport.request,
        api_key=cfg.api_key,
        requested_instance=cfg.instance_id,
        requested_team=cfg.team_id,
    )
    cfg.instance_id = identity.instance_id
    cfg.team_id = identity.team_id


async def _apply_identity_async(cfg: TransportConfig, transport: AsyncBobTransport) -> None:
    if cfg.instance_id and cfg.team_id:
        return
    identity = await resolve_identity_async(
        transport.request,
        api_key=cfg.api_key,
        requested_instance=cfg.instance_id,
        requested_team=cfg.team_id,
    )
    cfg.instance_id = identity.instance_id
    cfg.team_id = identity.team_id


def _populate_model_response(
    *, response_json: dict[str, Any], model_response: ModelResponse, model: str
) -> ModelResponse:
    model_response.id = response_json.get("id", model_response.id)
    model_response.created = response_json.get("created", model_response.created)
    model_response.model = response_json.get("model", model)
    model_response.choices = []
    for raw_choice in response_json.get("choices", []):
        msg = raw_choice.get("message", {}) or {}
        choice = Choices(
            finish_reason=raw_choice.get("finish_reason"),
            index=raw_choice.get("index", 0),
            message=Message(
                content=msg.get("content"),
                role=msg.get("role", "assistant"),
                tool_calls=msg.get("tool_calls"),
                function_call=msg.get("function_call"),
            ),
        )
        model_response.choices.append(choice)
    usage = response_json.get("usage")
    if usage:
        model_response.usage = usage  # type: ignore[assignment]
    return model_response


def _raise_for_status(response: httpx.Response) -> None:
    if response.is_success:
        return
    try:
        body = response.text
    except Exception:
        body = ""
    raise httpx.HTTPStatusError(
        f"IBM Bob {response.status_code}: {body[:500]}",
        request=response.request,
        response=response,
    )


def _parse_sse_line(line: str) -> GenericStreamingChunk | None:
    line = line.strip()
    if not line or not line.startswith("data:"):
        return None
    payload = line[len("data:") :].strip()
    if payload == "[DONE]":
        return GenericStreamingChunk(
            text="",
            tool_use=None,
            is_finished=True,
            finish_reason="stop",
            usage=None,
            index=0,
        )
    try:
        event = json.loads(payload)
    except json.JSONDecodeError:
        return None
    choices = event.get("choices") or []
    if not choices:
        usage = event.get("usage")
        if usage:
            return GenericStreamingChunk(
                text="",
                tool_use=None,
                is_finished=False,
                finish_reason="",
                usage=usage,
                index=0,
            )
        return None
    choice = choices[0]
    delta = choice.get("delta") or {}
    return GenericStreamingChunk(
        text=delta.get("content") or "",
        tool_use=None,
        is_finished=bool(choice.get("finish_reason")),
        finish_reason=choice.get("finish_reason") or "",
        usage=event.get("usage"),
        index=choice.get("index", 0),
    )


class IBMBobLLM(CustomLLM):
    """LiteLLM custom provider that proxies through IBM Bob's litellm-compatible backend."""

    def completion(  # type: ignore[override]
        self,
        model: str,
        messages: list[dict[str, Any]],
        api_base: str,
        custom_prompt_dict: dict[str, Any],
        model_response: ModelResponse,
        print_verbose: Any,
        encoding: Any,
        api_key: str | None,
        logging_obj: Any,
        optional_params: dict[str, Any],
        acompletion: Any = None,
        litellm_params: Any = None,
        logger_fn: Any = None,
        headers: dict[str, str] | None = None,
        timeout: Any = None,
        client: Any = None,
    ) -> ModelResponse:
        cfg = _resolve_config(
            api_key=api_key,
            api_base=api_base or None,
            optional_params=optional_params,
        )
        payload = _build_chat_payload(
            model=model, messages=messages, optional_params=optional_params, stream=False
        )
        with BobTransport(cfg) as transport:
            _apply_identity(cfg, transport)
            response = transport.request("POST", _chat_path(cfg), body=payload)
            _raise_for_status(response)
            return _populate_model_response(
                response_json=response.json(),
                model_response=model_response,
                model=_strip_prefix(model),
            )

    async def acompletion(  # type: ignore[override]
        self,
        model: str,
        messages: list[dict[str, Any]],
        api_base: str,
        custom_prompt_dict: dict[str, Any],
        model_response: ModelResponse,
        print_verbose: Any,
        encoding: Any,
        api_key: str | None,
        logging_obj: Any,
        optional_params: dict[str, Any],
        acompletion: Any = None,
        litellm_params: Any = None,
        logger_fn: Any = None,
        headers: dict[str, str] | None = None,
        timeout: Any = None,
        client: Any = None,
    ) -> ModelResponse:
        cfg = _resolve_config(
            api_key=api_key,
            api_base=api_base or None,
            optional_params=optional_params,
        )
        payload = _build_chat_payload(
            model=model, messages=messages, optional_params=optional_params, stream=False
        )
        async with AsyncBobTransport(cfg) as transport:
            await _apply_identity_async(cfg, transport)
            response = await transport.request("POST", _chat_path(cfg), body=payload)
            _raise_for_status(response)
            return _populate_model_response(
                response_json=response.json(),
                model_response=model_response,
                model=_strip_prefix(model),
            )

    def streaming(  # type: ignore[override]
        self,
        model: str,
        messages: list[dict[str, Any]],
        api_base: str,
        custom_prompt_dict: dict[str, Any],
        model_response: ModelResponse,
        print_verbose: Any,
        encoding: Any,
        api_key: str | None,
        logging_obj: Any,
        optional_params: dict[str, Any],
        acompletion: Any = None,
        litellm_params: Any = None,
        logger_fn: Any = None,
        headers: dict[str, str] | None = None,
        timeout: Any = None,
        client: Any = None,
    ) -> Iterator[GenericStreamingChunk]:
        cfg = _resolve_config(
            api_key=api_key,
            api_base=api_base or None,
            optional_params=optional_params,
        )
        payload = _build_chat_payload(
            model=model, messages=messages, optional_params=optional_params, stream=True
        )
        transport = BobTransport(cfg)
        try:
            _apply_identity(cfg, transport)
            response = transport.request("POST", _chat_path(cfg), body=payload, stream=True)
        except Exception:
            transport.close()
            raise
        try:
            _raise_for_status(response)
            for raw in response.iter_lines():
                chunk = _parse_sse_line(raw)
                if chunk is not None:
                    yield chunk
                    if chunk["is_finished"]:
                        break
        finally:
            response.close()
            transport.close()

    async def astreaming(  # type: ignore[override]
        self,
        model: str,
        messages: list[dict[str, Any]],
        api_base: str,
        custom_prompt_dict: dict[str, Any],
        model_response: ModelResponse,
        print_verbose: Any,
        encoding: Any,
        api_key: str | None,
        logging_obj: Any,
        optional_params: dict[str, Any],
        acompletion: Any = None,
        litellm_params: Any = None,
        logger_fn: Any = None,
        headers: dict[str, str] | None = None,
        timeout: Any = None,
        client: Any = None,
    ) -> AsyncIterator[GenericStreamingChunk]:
        cfg = _resolve_config(
            api_key=api_key,
            api_base=api_base or None,
            optional_params=optional_params,
        )
        payload = _build_chat_payload(
            model=model, messages=messages, optional_params=optional_params, stream=True
        )
        transport = AsyncBobTransport(cfg)
        try:
            await _apply_identity_async(cfg, transport)
            response = await transport.request("POST", _chat_path(cfg), body=payload, stream=True)
        except Exception:
            await transport.aclose()
            raise
        try:
            _raise_for_status(response)
            async for raw in response.aiter_lines():
                chunk = _parse_sse_line(raw)
                if chunk is not None:
                    yield chunk
                    if chunk["is_finished"]:
                        break
        finally:
            await response.aclose()
            await transport.aclose()

    def embedding(  # type: ignore[override]
        self,
        model: str,
        input: list[str],  # noqa: A002  (LiteLLM API)
        model_response: EmbeddingResponse,
        print_verbose: Any,
        logging_obj: Any,
        optional_params: dict[str, Any],
        api_key: str | None = None,
        api_base: str | None = None,
        timeout: Any = None,
        litellm_params: Any = None,
    ) -> EmbeddingResponse:
        cfg = _resolve_config(api_key=api_key, api_base=api_base, optional_params=optional_params)
        payload = {"model": _strip_prefix(model), "input": input}
        with BobTransport(cfg) as transport:
            _apply_identity(cfg, transport)
            response = transport.request("POST", EMBEDDINGS_PATH, body=payload)
            _raise_for_status(response)
            body = response.json()
        model_response.model = body.get("model", model)
        model_response.data = body.get("data", [])
        if "usage" in body:
            model_response.usage = body["usage"]  # type: ignore[assignment]
        return model_response

    async def aembedding(  # type: ignore[override]
        self,
        model: str,
        input: list[str],  # noqa: A002
        model_response: EmbeddingResponse,
        print_verbose: Any,
        logging_obj: Any,
        optional_params: dict[str, Any],
        api_key: str | None = None,
        api_base: str | None = None,
        timeout: Any = None,
        litellm_params: Any = None,
    ) -> EmbeddingResponse:
        cfg = _resolve_config(api_key=api_key, api_base=api_base, optional_params=optional_params)
        payload = {"model": _strip_prefix(model), "input": input}
        async with AsyncBobTransport(cfg) as transport:
            await _apply_identity_async(cfg, transport)
            response = await transport.request("POST", EMBEDDINGS_PATH, body=payload)
            _raise_for_status(response)
            body = response.json()
        model_response.model = body.get("model", model)
        model_response.data = body.get("data", [])
        if "usage" in body:
            model_response.usage = body["usage"]  # type: ignore[assignment]
        return model_response
