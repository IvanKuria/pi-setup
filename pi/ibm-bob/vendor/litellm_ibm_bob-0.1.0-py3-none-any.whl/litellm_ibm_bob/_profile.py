"""Instance/team auto-derivation — mirrors bob's setup flow.

bob fetches ``GET /admin/v1/profile`` once per session, then picks:

    instance = profile.instances.find(id == --instance-id) || profile.instances[0]
    team     = instance.teams.find(id == --team-id) || instance.teams[0]

Only non-legacy keys hit the authn backend that exposes the profile endpoint;
legacy ``sk-``/``pk-`` keys never trigger derivation.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx

from ._auth import KeyKind, classify_key
from ._constants import PROFILE_PATH


class ProfileFetchError(RuntimeError):
    """Raised when /admin/v1/profile cannot be loaded."""


@dataclass(slots=True, frozen=True)
class ResolvedIdentity:
    instance_id: str | None
    team_id: str | None


def _pick(
    profile: dict[str, Any], requested_instance: str | None, requested_team: str | None
) -> ResolvedIdentity:
    instances = profile.get("instances") or []
    instance: dict[str, Any] | None = None
    if requested_instance:
        instance = next((i for i in instances if i.get("instance_id") == requested_instance), None)
    if instance is None and instances:
        instance = instances[0]
    if instance is None:
        return ResolvedIdentity(instance_id=requested_instance, team_id=requested_team)
    teams = instance.get("teams") or []
    team: dict[str, Any] | None = None
    if requested_team:
        team = next((t for t in teams if t.get("id") == requested_team), None)
    if team is None and teams:
        team = teams[0]
    return ResolvedIdentity(
        instance_id=instance.get("instance_id") or requested_instance,
        team_id=(team.get("id") if team else None) or requested_team,
    )


def _eligible(api_key: str) -> bool:
    return classify_key(api_key) is not KeyKind.LEGACY


def resolve_identity_sync(
    request: Any,
    *,
    api_key: str,
    requested_instance: str | None,
    requested_team: str | None,
) -> ResolvedIdentity:
    """Synchronously resolve instance/team using ``request(METHOD, PATH)`` callable.

    ``request`` is typically ``BobTransport.request`` bound to an existing
    transport (so it reuses the same connection pool / signing pipeline).
    """

    if not _eligible(api_key):
        return ResolvedIdentity(instance_id=requested_instance, team_id=requested_team)
    response: httpx.Response = request("GET", PROFILE_PATH)
    if not response.is_success:
        raise ProfileFetchError(
            f"profile fetch failed: HTTP {response.status_code}: {response.text[:200]}"
        )
    return _pick(response.json(), requested_instance, requested_team)


async def resolve_identity_async(
    request: Any,
    *,
    api_key: str,
    requested_instance: str | None,
    requested_team: str | None,
) -> ResolvedIdentity:
    if not _eligible(api_key):
        return ResolvedIdentity(instance_id=requested_instance, team_id=requested_team)
    response: httpx.Response = await request("GET", PROFILE_PATH)
    if not response.is_success:
        raise ProfileFetchError(
            f"profile fetch failed: HTTP {response.status_code}: {response.text[:200]}"
        )
    return _pick(response.json(), requested_instance, requested_team)
