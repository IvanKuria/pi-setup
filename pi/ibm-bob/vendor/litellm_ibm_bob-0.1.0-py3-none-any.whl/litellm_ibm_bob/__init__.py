"""LiteLLM custom provider for IBM Bob (bobshell) backend.

Importing this package registers an ``ibm-bob`` provider with LiteLLM.
"""

from __future__ import annotations

import litellm

from ._auth import KeyKind, base_url_for, classify_key
from ._constants import (
    BOBSHELL_VERSION,
    BUILD_TIME_HMAC_SECRET,
    DEFAULT_BACKEND_URL,
    DEFAULT_OLD_BACKEND_URL,
    USER_AGENT,
)
from .provider import PROVIDER_NAME, IBMBobLLM

__all__ = [
    "BOBSHELL_VERSION",
    "BUILD_TIME_HMAC_SECRET",
    "DEFAULT_BACKEND_URL",
    "DEFAULT_OLD_BACKEND_URL",
    "PROVIDER_NAME",
    "USER_AGENT",
    "IBMBobLLM",
    "KeyKind",
    "base_url_for",
    "classify_key",
]


def _register() -> None:
    handler = IBMBobLLM()
    existing = list(getattr(litellm, "custom_provider_map", None) or [])
    if any(entry.get("provider") == PROVIDER_NAME for entry in existing):
        return
    existing.append({"provider": PROVIDER_NAME, "custom_handler": handler})
    litellm.custom_provider_map = existing


_register()
