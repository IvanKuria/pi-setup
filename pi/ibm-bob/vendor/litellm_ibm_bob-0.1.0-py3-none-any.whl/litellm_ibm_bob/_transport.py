"""HTTP transport for the IBM Bob backend.

Wraps ``httpx.Client`` / ``httpx.AsyncClient`` with:
* Authorization + tracking headers (instance/team id).
* HMAC signing for prod-host requests.
* Retry-with-backoff on 408/429/5xx + Bob-specific transient errors.
"""

from __future__ import annotations

import asyncio
import json
import time
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlsplit

import httpx

from . import _auth, _signing
from ._constants import (
    BUILD_TIME_HMAC_SECRET,
    DEFAULT_MAX_RETRIES,
    DEFAULT_RETRY_DELAY_SECONDS,
    DEFAULT_TIMEOUT_SECONDS,
    USER_AGENT,
)

_RETRY_BODY_MARKERS = (
    "Error getting user_id from apikey",
    "All connection attempts failed",
)


class BobHTTPError(httpx.HTTPError):
    """Raised when retries are exhausted or a non-retryable error occurs."""

    def __init__(self, message: str, *, response: httpx.Response | None = None) -> None:
        super().__init__(message)
        self.response = response


@dataclass(slots=True)
class TransportConfig:
    api_key: str
    base_url: str | None = None
    instance_id: str | None = None
    team_id: str | None = None
    hmac_secret: str | None = BUILD_TIME_HMAC_SECRET
    timeout: float = DEFAULT_TIMEOUT_SECONDS
    max_retries: int = DEFAULT_MAX_RETRIES
    retry_delay: float = DEFAULT_RETRY_DELAY_SECONDS
    user_agent: str = USER_AGENT

    def resolved_base_url(self) -> str:
        return _auth.base_url_for(self.api_key, override=self.base_url)


def _build_headers(
    *,
    method: str,
    url: str,
    body_string: str,
    cfg: TransportConfig,
    extra_headers: dict[str, str] | None = None,
) -> dict[str, str]:
    kind = _auth.classify_key(cfg.api_key)
    headers: dict[str, str] = {
        "Content-Type": "application/json",
        "User-Agent": cfg.user_agent,
        "Authorization": _auth.authorization_header(cfg.api_key, kind=kind),
    }
    if cfg.instance_id:
        headers["x-instance-id"] = cfg.instance_id
    if cfg.team_id:
        headers["x-team-id"] = cfg.team_id

    base_url = cfg.resolved_base_url()
    if cfg.hmac_secret and _auth.should_sign_url(url, base_url):
        parsed = urlsplit(url)
        path_and_query = parsed.path or "/"
        if parsed.query:
            path_and_query = f"{path_and_query}?{parsed.query}"
        sig = _signing.sign_request(
            method=method,
            path_with_query=path_and_query,
            body=body_string,
            secret=cfg.hmac_secret,
        )
        headers.update(sig)

    if extra_headers:
        headers.update(extra_headers)
    return headers


def _absolute_url(base_url: str, path: str) -> str:
    if path.startswith(("http://", "https://")):
        return path
    return f"{base_url.rstrip('/')}{path if path.startswith('/') else '/' + path}"


def _serialize_body(body: Any) -> str:
    if body is None:
        return ""
    if isinstance(body, str):
        return body
    if isinstance(body, (bytes, bytearray)):
        return bytes(body).decode("utf-8")
    return json.dumps(body, separators=(",", ":"), ensure_ascii=False)


def _backoff(attempt: int, retry_delay: float) -> float:
    return retry_delay * (2**attempt)


class BobTransport:
    """Synchronous transport. Use one per process (httpx pools connections)."""

    def __init__(self, cfg: TransportConfig, *, client: httpx.Client | None = None) -> None:
        self.cfg = cfg
        self._client = client or httpx.Client(timeout=cfg.timeout)
        self._owns_client = client is None

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def __enter__(self) -> BobTransport:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def request(
        self,
        method: str,
        path: str,
        *,
        body: Any = None,
        extra_headers: dict[str, str] | None = None,
        stream: bool = False,
    ) -> httpx.Response:
        url = _absolute_url(self.cfg.resolved_base_url(), path)
        body_str = _serialize_body(body)
        content = body_str.encode("utf-8") if body_str else None
        last_error: Exception | None = None
        last_response: httpx.Response | None = None
        for attempt in range(self.cfg.max_retries):
            headers = _build_headers(
                method=method,
                url=url,
                body_string=body_str,
                cfg=self.cfg,
                extra_headers=extra_headers,
            )
            try:
                if stream:
                    request = self._client.build_request(
                        method, url, headers=headers, content=content
                    )
                    response = self._client.send(request, stream=True)
                else:
                    response = self._client.request(method, url, headers=headers, content=content)
            except httpx.HTTPError as exc:
                last_error = exc
                if attempt == self.cfg.max_retries - 1:
                    break
                time.sleep(_backoff(attempt, self.cfg.retry_delay))
                continue

            if response.is_success or not _should_retry_response(response, stream):
                return response

            last_response = response
            if stream:
                response.close()
            if attempt == self.cfg.max_retries - 1:
                return response
            time.sleep(_backoff(attempt, self.cfg.retry_delay))

        if last_response is not None:
            return last_response
        raise BobHTTPError(
            f"Request failed after {self.cfg.max_retries} attempts: {last_error}",
        )


class AsyncBobTransport:
    """Async twin of :class:`BobTransport`."""

    def __init__(self, cfg: TransportConfig, *, client: httpx.AsyncClient | None = None) -> None:
        self.cfg = cfg
        self._client = client or httpx.AsyncClient(timeout=cfg.timeout)
        self._owns_client = client is None

    async def aclose(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    async def __aenter__(self) -> AsyncBobTransport:
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.aclose()

    async def request(
        self,
        method: str,
        path: str,
        *,
        body: Any = None,
        extra_headers: dict[str, str] | None = None,
        stream: bool = False,
    ) -> httpx.Response:
        url = _absolute_url(self.cfg.resolved_base_url(), path)
        body_str = _serialize_body(body)
        content = body_str.encode("utf-8") if body_str else None
        last_error: Exception | None = None
        last_response: httpx.Response | None = None
        for attempt in range(self.cfg.max_retries):
            headers = _build_headers(
                method=method,
                url=url,
                body_string=body_str,
                cfg=self.cfg,
                extra_headers=extra_headers,
            )
            try:
                if stream:
                    request = self._client.build_request(
                        method, url, headers=headers, content=content
                    )
                    response = await self._client.send(request, stream=True)
                else:
                    response = await self._client.request(
                        method, url, headers=headers, content=content
                    )
            except httpx.HTTPError as exc:
                last_error = exc
                if attempt == self.cfg.max_retries - 1:
                    break
                await asyncio.sleep(_backoff(attempt, self.cfg.retry_delay))
                continue

            if response.is_success or not _should_retry_response(response, stream):
                return response

            last_response = response
            if stream:
                await response.aclose()
            if attempt == self.cfg.max_retries - 1:
                return response
            await asyncio.sleep(_backoff(attempt, self.cfg.retry_delay))

        if last_response is not None:
            return last_response
        raise BobHTTPError(
            f"Request failed after {self.cfg.max_retries} attempts: {last_error}",
        )


def _should_retry_response(response: httpx.Response, stream: bool) -> bool:
    if response.is_success:
        return False
    if response.status_code >= 500 or response.status_code in (408, 429):
        return True
    if stream:
        return False
    try:
        text = response.text
    except Exception:
        return False
    return any(marker in text for marker in _RETRY_BODY_MARKERS)


__all__ = [
    "AsyncBobTransport",
    "BobHTTPError",
    "BobTransport",
    "TransportConfig",
    "_absolute_url",
    "_serialize_body",
]
